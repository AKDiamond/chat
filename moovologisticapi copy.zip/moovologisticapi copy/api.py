from flask import  Flask, request, jsonify,session, redirect, url_for,g,abort, Response
from functools import wraps
from google.appengine.api import urlfetch
import ast
from time import gmtime, strftime
import cloudDbHandler as dbhelper
from sets import  Set
import time
import json
import math
import ast
import unicodedata
from datetime import datetime
import random
from math import radians, cos, sin, asin, sqrt
import re
import urllib
from random import randint
from google.appengine.api import urlfetch

app = Flask(__name__)

# This function to be run after each request.This function must take one parameter, a response_class object and return a new response object or the same to http call
# with defined allowable Headers, Origin and Methods
@app.after_request
def after_request(response):
	response.headers['Access-Control-Allow-Origin']='*'
	response.headers['Access-Control-Allow-Headers']='Content-Type, Authorization'
	response.headers['Access-Control-Allow-Methods']= 'GET, PUT, POST, DELETE'
	return response

@app.route('/api/server/check/',methods=['GET'])
def server_check():
	if request.method=='GET':
		resp = Response(json.dumps({"success": "GET"}))
		return after_request(resp)


@app.route('/api/profile/check/',methods=['GET','POST'])
def profileCheck():
	if request.method=='POST':
		json_results=[]
		data=json.loads(request.data)
		phoneNumber = data['phone']
		result = dbhelper.GetData().getAccountInfo(phoneNumber)
		if len(result) > 0:
			db = "Number Already Registered!"
			success = 0
		else :
			db = "Number Not registered!"
			success = 1
		resp = Response(json.dumps({"success": success, "message":db}))
		return after_request(resp)


if __name__ == "__main__":
	app.run()

	