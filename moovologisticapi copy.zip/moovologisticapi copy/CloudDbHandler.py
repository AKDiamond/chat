import os
import httplib2
from google.appengine.api import memcache
from apiclient.discovery import build
from google.appengine.api import rdbms
import datetime
import time


_INSTANCE_NAME = 'moovo-967:apicall'

class AddData():
	def function():
		pass

class GetData():

	def getAccountInfo(self,phoneNumber):
		try:
			dbname='moovo_logistics'
			conn = rdbms.connect(instance=_INSTANCE_NAME, database=dbname)
			cursor = conn.cursor()
			sqlcmd = 'select * from account_details where phoneNumber="%s"'%str(phoneNumber)
			cursor.execute(sqlcmd)	
			dbDetails=[]
			for row in cursor.fetchall():
				dbDetails.append(row)
			conn.commit()
			conn.close()
			return dbDetails 
		except Exception,e:
			print str(e)

class UpdateData(object):
	def function():
		pass